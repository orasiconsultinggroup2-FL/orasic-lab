# Tipografía — ORASIC Lab

Extraído directamente de `index.html` (`<link>` de Google Fonts + reglas CSS). Aquí no hay inconsistencias — el sitio usa exactamente dos familias, con roles bien separados.

## Familias

### Space Grotesk
- **Uso:** todos los títulos y encabezados (`h1, h2, h3, h4, h5`).
- **Pesos cargados:** 500 (medium), 600 (semibold), 700 (bold).
- **Carácter:** geométrica, moderna, con personalidad técnica — es la que le da el aire "lab/tech" a la marca, contrasta con el fondo oscuro.
- **Google Fonts:** `Space+Grotesk:wght@500;600;700`

### Inter
- **Uso:** todo el cuerpo de texto (`body`), párrafos, botones, formularios, navegación.
- **Pesos cargados:** 300 (light), 400 (regular), 500 (medium), 600 (semibold), 700 (bold).
- **Carácter:** sans-serif neutra, muy legible en pantalla, estándar de producto — deja que Space Grotesk sea la que "hable" en los títulos.

## Jerarquía tal como está implementada
- H1 (hero): Space Grotesk, 700, tamaños responsivos 4xl→7xl
- H2 (secciones): Space Grotesk, 700, 3xl→5xl
- H3/H4: Space Grotesk, 700/600, tamaños menores
- Cuerpo/párrafos: Inter, 300-400, con `leading-relaxed`
- Labels/uppercase (categorías, botones): Inter, 700, tracking amplio (`tracking-widest` / `tracking-[0.2em]` o `[0.3em]`)

## Nota
Estas son las únicas dos fuentes cargadas en el sitio. Si en el futuro se usa una tercera fuente en algún asset de redes o documento, debería justificarse por qué — el sistema actual es intencionalmente minimalista (2 familias, roles claros).
