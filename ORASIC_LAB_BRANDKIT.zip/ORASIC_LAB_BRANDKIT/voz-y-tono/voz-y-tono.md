# Voz y Tono — ORASIC Lab

Este documento es un análisis del copy que ya existe (index.html, bios de Instagram/TikTok) — no son reglas inventadas, son patrones que ya están presentes y que conviene que queden explícitos para que cualquier pieza nueva (post, mensaje, pitch) suene consistente.

## Slogan / ancla de marca
**"Tu negocio, hecho aplicación."**
Aparece en el hero implícitamente ("Convertimos tu negocio en una aplicación real"), en las bios de Instagram/TikTok textualmente, y en el footer. Es el ancla — cualquier pieza nueva debería poder conectarse a esta idea.

## Rasgos observados en el copy real

**1. Habla del dolor concreto, no de la solución abstracta primero**
Ejemplo real: *"El Costo de Seguir Improvisando"* — antes de hablar de features, el sitio nombra el problema tal como lo vive el dueño de negocio: reservas anotadas a mano, clientes perdidos en el chat, reportes armados a última hora. No abre con "ofrecemos soluciones de software".

**2. Cita literalmente cómo habla el cliente, no cómo habla una agencia**
Los "dolores" en la Guía Maestra están escritos en primera persona tal como los diría el dueño del negocio: *"Tengo todo en Excel y no tengo visibilidad real"*, *"Me da miedo la multa de SUNAT"*, *"Mi caja registradora es lenta y se traba"*. Este es un patrón fuerte y deliberado — el copy no describe el dolor desde afuera, lo pone entre comillas como si el cliente mismo lo dijera.

**3. Español peruano, tuteo, cercano pero no informal en exceso**
"Cuéntame tu idea", "Cuéntanos tu idea", "Diagnóstico" en vez de "consultoría inicial". No usa anglicismos innecesarios ni jerga corporativa ("sinergias", "disrupción", "ecosistema de valor").

**4. Contraste directo — lo viejo vs. lo nuevo, con em-dash**
*"para negocios que quieren dejar el WhatsApp desordenado y el Excel atrás"*, *"No entregamos código y desaparecemos"*. El patrón de "no hacemos X — hacemos Y" o "antes/después" aparece varias veces y es efectivo porque es concreto, no genérico.

**5. Cifras específicas, no adjetivos vagos**
100+ apps, 12 rubros, 2 países, <24h de respuesta. Evita "muchas apps" o "rápida respuesta" — siempre que se pueda, un número real reemplaza al adjetivo.

**6. Objeciones respondidas de frente, sin rodeos (ver sección FAQ)**
"¿Cuánto cuesta?", "¿Cuánto se demora?", "No tengo conocimientos técnicos, ¿igual puedo pedir una app?" — el tono en las respuestas es directo y sin evasivas ("Depende del alcance, pero..." en vez de no responder el precio).

**7. Reafirma el compromiso post-entrega como diferenciador central**
No es un detalle menor — aparece repetido en el hero secundario ("Por qué ORASIC Lab"), en el FAQ y en la descripción larga del perfil: *"no entregamos el código y desaparecemos"*. Es probablemente el mensaje de confianza más importante de la marca, más que la IA o el precio.

**8. Emojis: mínimos y funcionales, no decorativos**
En bios: 🚀 (cierre de una frase de impacto), 👇 (dirige la mirada a la acción), 🇵🇪🇨🇴 (cobertura geográfica). No se usan en el sitio web ni en el copy largo — quedan reservados a redes sociales/bios cortas.

## Lo que NO hace esta marca (por ausencia consistente en todo el copy)
- No usa superlativos vacíos ("el mejor", "líder en el mercado") — deja que las cifras hablen.
- No promete resultados exagerados ni casos ficticios (coherente con la regla ya explícita en CLAUDE.md de no inventar testimonios).
- No usa jerga técnica de desarrollo hacia el cliente (no dice "API", "backend", "stack" en el copy orientado a pymes).

## Frase de referencia para cualquier pieza nueva
Antes de publicar algo nuevo, probarlo contra esto: *¿esto suena a algo que un dueño de negocio real diría sobre su propio problema, o suena a lo que una agencia diría sobre su servicio?* El copy que ya funciona en el sitio siempre elige lo primero.
