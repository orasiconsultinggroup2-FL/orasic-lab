# Brandkit ORASIC Lab

Organizado el 09/08/2026 a partir de lo que ya existe en el proyecto: `CLAUDE.md`, `index.html`, `Datos_para_llenar_perfiles.md` y los logos subidos.

## Estructura
```
ORASIC_LAB_BRANDKIT/
├── logos/
│   ├── logo-principal-circular.png       (isotipo + wordmark, versión circular)
│   ├── logo-horizontal-con-texto.png     (versión horizontal, para headers/firmas)
│   ├── isotipo-solo-simbolo.png          (solo el símbolo de 4 nodos, sin texto)
│   ├── og-image-social-share.png         (imagen para compartir en redes/links)
│   └── referencia-comparacion-A-vs-B.png (guía de cuándo usar A "con texto" vs B "solo símbolo")
├── fuentes/
│   └── tipografia.md                     (Space Grotesk + Inter, pesos y roles)
├── colores/
│   └── colores-corporativos.md           (paleta real + inconsistencia detectada vs. CLAUDE.md)
└── voz-y-tono/
    └── voz-y-tono.md                     (patrones de copy extraídos del sitio real)
```

## Cómo usar esto
1. Descarga la carpeta completa (te la doy en .zip).
2. Muévela dentro de tu carpeta real del proyecto ORASIC Lab (la que sincroniza OneDrive), por ejemplo como `/brandkit/`.
3. El único punto que requiere una decisión tuya: en `colores/colores-corporativos.md` hay una inconsistencia real entre el violeta documentado en CLAUDE.md (`#A78BFA`) y el violeta usado en botones/CTAs del sitio en vivo (`#7C3AED`). Conviene que definas cuál es "el" violeta oficial y actualices el que quedó desactualizado — no lo resolví por ti porque es una decisión de marca, no un error técnico obvio.

## Lo que NO incluí
- No inventé una guía de "tono de voz" genérica tipo plantilla — todo lo de `voz-y-tono.md` está extraído y citado del copy que ya escribiste/aprobaste en el sitio. Si algo ahí no te representa, es porque el sitio actual tampoco lo representa, y vale la pena revisarlo ahí primero.
- No creé variantes nuevas de logo — solo organicé y renombré descriptivamente los 5 archivos de imagen que ya tenías.
