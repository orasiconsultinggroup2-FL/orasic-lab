# Colores Corporativos — ORASIC Lab

Extraído comparando `CLAUDE.md` (documentación oficial de marca) contra `index.html` (lo que está en vivo). Hay una diferencia real entre ambos que conviene que sepas antes de generar más assets.

## ⚠️ Inconsistencia detectada

| Color | Documentado en CLAUDE.md | Usado realmente en el sitio |
|---|---|---|
| Violeta | `#A78BFA` (único valor) | `#A78BFA` en textos/gradientes de títulos, pero `#7C3AED` en botones y CTAs (el violeta "de acción" es más oscuro/saturado que el documentado) |
| Fondo | `#080A0F` | `#05060a` (fondo base) y `#0a0d17` (fondo de secciones alternas) |

Cyan, rosa y naranja sí coinciden exactamente entre el documento y el sitio — no hay problema ahí.

**Qué significa esto en la práctica:** si generas gráficos de redes (Python/PIL) usando solo el violeta `#A78BFA` del CLAUDE.md, te va a salir un violeta más claro/pastel que el de los botones reales del sitio. Si quieres que los assets de contenido combinen con el look de "acción" (botones, CTAs), necesitas el `#7C3AED`. Si quieres que combinen con el look de "texto destacado" (headings, acentos), el `#A78BFA` documentado es el correcto. Vale la pena decidir cuál es el violeta "oficial" único y actualizar el que quede desactualizado (CLAUDE.md o el propio sitio).

---

## Paleta completa (valores reales verificados en index.html)

### Fondos
| Uso | Hex | Vista previa |
|---|---|---|
| Fondo base (body) | `#05060a` | ██ casi negro |
| Fondo de secciones alternas | `#0a0d17` | ██ negro azulado |

### Violeta (marca)
| Uso | Hex | Nombre Tailwind equivalente |
|---|---|---|
| Botones / CTAs / acento principal | `#7C3AED` | violet-600 |
| Bordes, líneas divisoras | `#8B5CF6` | violet-500 |
| Texto de gradiente en títulos, acentos suaves | `#A78BFA` | violet-400 |

### Cyan
| Uso | Hex |
|---|---|
| Texto de categoría, hover de links, acentos | `#22D3EE` |
| Puntos decorativos en tarjetas de servicios | `#06B6D4` |

### Rosa (usado como color de rubro "Belleza")
| Uso | Hex |
|---|---|
| Acento rosa | `#F472B6` |

### Naranja (usado como color de rubro "Deporte")
| Uso | Hex |
|---|---|
| Acento naranja | `#FB923C` |

### Texto
| Uso | Hex |
|---|---|
| Texto principal sobre fondo oscuro | `#E2E8F0` (slate-200) |
| Texto secundario / párrafos | tonos slate-400/500 (`#94A3B8` / `#64748B`) |

---

## Origen del sistema de color
El logo (icono de 4 nodos en diamante) es la fuente original de la paleta de 4 colores de acento: violeta, cyan, rosa, naranja — conectados entre sí, sobre fondo casi negro. Esto es coherente en todos los assets: landing, logos, contenido de redes.
